# Baklol Dialer — Android Studio starter project

This is a native Kotlin Android project scaffold for the Baklol Dialer concept. It includes a premium dark dial pad, theme accent switching, a request to become the default phone app, outgoing call intent, and an `InCallService` / call screen starter.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open the `BaklolDialer` folder in Android Studio.
3. Let Gradle sync and install the Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Run the app. In the app, tap **Set as default phone app** and approve Android's system dialog.
6. To create an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will show the APK output path.

## Important status
- This is source code, not a prebuilt or device-tested APK. Gradle/Android SDK are not available in this environment, so the project has not been compiled here.
- Android dialer eligibility and full-screen incoming call behaviour vary by Android version and device. Test on a real phone and finish the required call-state handling before daily use.
- Recording is deliberately not implemented. Android restricts call audio capture on many devices/versions and local laws may require consent. The Record button is informational only.
- Contact photo wallpapers, full contact lookup, spam detection, dual-SIM selection, ringtone management, and production-grade in-call audio routing remain to be implemented.
- Do not use as your only phone app until call answer/decline, emergency calling, Bluetooth, speaker, SIM selection and background behaviour are thoroughly tested.
