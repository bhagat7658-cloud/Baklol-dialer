package com.baklol.dialer

import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService

class BaklolInCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallHolder.current = call
        val i = Intent(this, CallActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(i)
    }
    override fun onCallRemoved(call: Call) {
        if (CallHolder.current === call) CallHolder.current = null
        super.onCallRemoved(call)
    }
}
object CallHolder { @Volatile var current: Call? = null }
