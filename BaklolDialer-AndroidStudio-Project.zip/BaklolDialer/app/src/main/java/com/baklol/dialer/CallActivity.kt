package com.baklol.dialer

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.telecom.Call
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class CallActivity : Activity() {
    private var callback: Call.Callback? = null
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=0xff141018.toInt(); window.navigationBarColor=0xff08090b.toInt(); render() }
    private fun render(){
        val call=CallHolder.current
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(24,24,24,24); setBackgroundColor(0xff17131b.toInt()) }
        root.addView(TextView(this).apply { text="♛ BAKLOL DIALER"; textSize=15f; setTextColor(0xfff0c477.toInt()); gravity=Gravity.CENTER; setPadding(0,0,0,38) })
        root.addView(TextView(this).apply { text="${call?.details?.handle?.schemeSpecificPart ?: "Unknown caller"}"; textSize=28f; setTextColor(Color.WHITE); gravity=Gravity.CENTER })
        root.addView(TextView(this).apply { text=when(call?.state){Call.STATE_RINGING->"Incoming call";Call.STATE_DIALING,Call.STATE_CONNECTING->"Calling…";Call.STATE_ACTIVE->"Connected";else->"Call"}; textSize=15f; setTextColor(0xfff0c477.toInt()); gravity=Gravity.CENTER; setPadding(0,12,0,36) })
        if(call?.state==Call.STATE_RINGING) root.addView(button("Answer",0xff2fbf71.toInt()){call.answer(android.telecom.VideoProfile.STATE_AUDIO_ONLY);render()})
        root.addView(button("Mute / Unmute",0xff303039.toInt()){Toast.makeText(this,"Mute control needs an InCallService audio-state connection; not enabled in this starter build.",Toast.LENGTH_SHORT).show()})
        root.addView(button("Speaker",0xff303039.toInt()){Toast.makeText(this,"Audio routing depends on Android/device support",Toast.LENGTH_SHORT).show()})
        root.addView(button("Record",0xff4c3820.toInt()){Toast.makeText(this,"Call recording is restricted on many Android devices; this button does not record audio yet.",Toast.LENGTH_LONG).show()})
        root.addView(button(if(call?.state==Call.STATE_RINGING)"Decline" else "End call",0xffdf343a.toInt()){ if(call?.state==Call.STATE_RINGING) call.reject(false,null) else call?.disconnect(); finish() })
        root.addView(TextView(this).apply { text="Contact wallpapers and actual recording integration are the next implementation stage."; textSize=11f; setTextColor(0xffb8b0bc.toInt()); gravity=Gravity.CENTER; setPadding(0,22,0,0) })
        setContentView(root)
    }
    private fun button(label:String,bg:Int,action:()->Unit)=Button(this).apply { text=label; isAllCaps=false; textSize=15f; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg)); setOnClickListener { action() }; val p=LinearLayout.LayoutParams(-1,56); p.setMargins(0,5,0,5); layoutParams=p }
}
