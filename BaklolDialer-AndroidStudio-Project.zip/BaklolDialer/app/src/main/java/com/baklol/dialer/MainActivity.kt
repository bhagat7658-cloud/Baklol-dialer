package com.baklol.dialer

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.telecom.TelecomManager

class MainActivity : Activity() {
    private lateinit var number: EditText
    private var accent = Color.rgb(240,196,119)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=Color.rgb(8,9,11); window.navigationBarColor=Color.rgb(8,9,11); buildUi() }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,24,22,18); setBackgroundColor(Color.rgb(8,9,11)) }
        root.addView(TextView(this).apply { text="♛ BAKLOL DIALER"; textSize=28f; setTextColor(accent); gravity=Gravity.CENTER; setPadding(0,10,0,2) })
        root.addView(TextView(this).apply { text="Calls bhi. Bakchodi bhi. Premium always."; textSize=12f; setTextColor(0xffaaa8a5); gravity=Gravity.CENTER; setPadding(0,0,0,24) })
        val roleBtn=btn("Set as default phone app",accent,Color.BLACK); roleBtn.setOnClickListener { requestDialerRole() }; root.addView(roleBtn,lp())
        number=EditText(this).apply { hint="Enter phone number"; textSize=24f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setHintTextColor(0xff777777); setSingleLine(true); setPadding(10,18,10,18); setBackgroundColor(0xff191919); inputType=3 }
        val numberLp=lp(); numberLp.setMargins(0,18,0,12); root.addView(number,numberLp)
        val keys=listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO", "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
        for (r in 0 until 4) { val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }; for(c in 0..2){val (digit,letters)=keys[r*3+c]; val b=Button(this).apply { text=if(letters.isEmpty()) digit else "$digit\n$letters"; textSize=17f; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff202124)); setOnClickListener { number.append(digit) } }; val p=LinearLayout.LayoutParams(0,64,1f); p.setMargins(5,5,5,5); row.addView(b,p)}; root.addView(row,ViewGroup.LayoutParams(-1,-2)) }
        val call=btn("☎   CALL",accent,Color.BLACK); call.setOnClickListener { placeCall() }; val callLp=lp(); callLp.setMargins(0,14,0,8); root.addView(call,callLp)
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row.addView(btn("Recent calls",0xff202124,Color.WHITE).apply { setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://call_log/calls"))) } },LinearLayout.LayoutParams(0,52,1f).apply{setMargins(0,4,5,4)})
        row.addView(btn("Contacts",0xff202124,Color.WHITE).apply { setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people"))) } },LinearLayout.LayoutParams(0,52,1f).apply{setMargins(5,4,0,4)})
        root.addView(row)
        root.addView(TextView(this).apply { text="PREMIUM THEMES"; textSize=13f; setTextColor(accent); setPadding(0,22,0,10) })
        val themes=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("Royal Gold" to 0xfff0c477.toInt(),"Neon Purple" to 0xffbd8cff.toInt(),"Mint Luxe" to 0xff7be5cc.toInt(),"Crimson" to 0xffff756e.toInt()).forEach { (name,color)-> themes.addView(btn(name,color,Color.BLACK).apply { textSize=10f; setOnClickListener { accent=color; Toast.makeText(this@MainActivity,"$name selected",Toast.LENGTH_SHORT).show(); buildUi() } },LinearLayout.LayoutParams(0,52,1f).apply{setMargins(3,0,3,0)}) }
        root.addView(themes)
        root.addView(TextView(this).apply { text="Call screen · large contact wallpaper · recording controls (device-supported only) · spam protection roadmap"; textSize=11f; setTextColor(0xffaaa8a5); gravity=Gravity.CENTER; setPadding(4,20,4,0) })
        setContentView(root)
    }
    private fun lp()=LinearLayout.LayoutParams(-1,-2)
    private fun btn(label:String,bg:Int,fg:Int)=Button(this).apply { text=label; textSize=14f; setTextColor(fg); setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg)); isAllCaps=false; minHeight=48 }
    private fun requestDialerRole(){ if(Build.VERSION.SDK_INT>=Q){val rm=getSystemService(RoleManager::class.java); if(rm.isRoleAvailable(RoleManager.ROLE_DIALER)&&!rm.isRoleHeld(RoleManager.ROLE_DIALER)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER),200) else Toast.makeText(this,"Baklol Dialer is already the default phone app",Toast.LENGTH_LONG).show()} else Toast.makeText(this,"Set Baklol Dialer from Settings > Default apps > Phone app",Toast.LENGTH_LONG).show() }
    private fun placeCall(){ val n=number.text.toString().trim(); if(n.isBlank()){Toast.makeText(this,"Enter a number first",Toast.LENGTH_SHORT).show();return}; try { startActivity(Intent(Intent.ACTION_CALL,Uri.parse("tel:${Uri.encode(n)}"))) } catch(e:Exception){startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:${Uri.encode(n)}")))} }
    companion object { private const val Q=29 }
}
